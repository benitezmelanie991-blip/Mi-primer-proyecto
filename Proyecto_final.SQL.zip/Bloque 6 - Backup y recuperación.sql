
----------------------------- Backup y Recuperación --------------------------------

-- RPO objetivo: 15 minutos
-- RTO objetivo: 1 hora

USE Proyecto_final
GO

-- 1. Asegurar el modelo de recuperación completa
ALTER DATABASE Proyecto_final
SET RECOVERY FULL;
GO

-- Backup Base (Completo) 
BACKUP DATABASE Proyecto_final
TO DISK = 'C:\SqlDatos\Proyecto_final_Full.bak'
WITH INIT, NAME = 'Backup Completo de Proyecto_final';
GO

-- Backup Diferencial 
BACKUP DATABASE Proyecto_final
TO DISK = 'C:\SqlDatos\Proyecto_final_Diff.bak'
WITH INIT, NAME = 'Backup Diferencial de Proyecto_final';
GO

-- Backup del Log de Transacciones 
BACKUP LOG Proyecto_final
TO DISK = 'C:\SqlDatos\Proyecto_final_Log.trn'
WITH INIT, NAME = 'Backup de Log de Proyecto_final';
GO

-----------------------------------------------------------
-----------------------------------------------------------
-- Script de restauración
-----------------------------------------------------------
-----------------------------------------------------------

USE Master;
GO

-- Cerramos todas las conexiones activas a la base de datos para evitar bloqueos
ALTER DATABASE Proyecto_final 
SET SINGLE_USER 
WITH ROLLBACK IMMEDIATE;
GO

-- Restauramos el Backup Completo 
RESTORE DATABASE Proyecto_final
FROM DISK = 'C:\SqlDatos\Proyecto_final_Full.bak'
WITH NORECOVERY, REPLACE;
GO

-- Restauramos el Backup Diferencial
RESTORE DATABASE Proyecto_final
FROM DISK = 'C:\SqlDatos\Proyecto_final_Diff.bak'
WITH NORECOVERY;
GO

-- Restauramos el Log de Transacciones 
RESTORE LOG Proyecto_final
FROM DISK = 'C:\SqlDatos\Proyecto_final_Log.trn'
WITH RECOVERY;
GO

-- Devovemos la base de datos a su modo multiusuario normal
ALTER DATABASE Proyecto_final 
SET MULTI_USER;
GO
