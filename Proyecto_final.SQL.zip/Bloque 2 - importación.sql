

--------------------------------------- IMPORTACIÓN DE DATOS --------------------------------------------------------

USE Proyecto_final
GO

BULK INSERT dbo.clientes --- archivo clientes desde CSV
FROM 'C:\Users\benit\Downloads\Tabla clientes importación.txt'
WITH (
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',   
    FIRSTROW = 2           
);

SELECT*FROM clientes;

-------------------- problemas encontrados y solución aplicada.

--Bulk load data conversion error (type mismatch or invalid character for the specified codepage) for row 2, column 8 (activo).
Mens. 4864, Nivel 16, Estado 1, Línea 8
--Bulk load data conversion error (type mismatch or invalid character for the specified codepage) for row 3, column 8 (activo).

-- Se verifica que el error fue no colocar la fila activo en el archivo por lo que SQL server intentaba colocar la fecha_ingreso en la columna activo.
La solución fue agregar la columna en el archivo.

USE Proyecto_final
GO

INSERT INTO dbo.productos (nombre, precio, stock, categoria_id) -- archivo prodcutos json
SELECT nombre, precio, stock, categoria_id
FROM OPENROWSET (BULK 'C:\SqlDatos\Tabla Productos json.txt', SINGLE_CLOB) as archivo_json
CROSS APPLY OPENJSON (BulkColumn)
WITH (
    nombre VARCHAR(100) '$.nombre',
    precio DECIMAL(10,2) '$.precio',
    stock INT '$.stock',
    categoria_id INT '$.categoria_id'
);

SELECT*FROM productos;