

------------------------------------------ Lógica de negocio ---------------------------------------------------
USE Proyecto_final
GO

CREATE FUNCTION dbo.precio_total() -- calcula el valor total de todo el inventario que actualmente hay disponible para vender.
RETURNS DECIMAL(10,2)
AS
BEGIN
DECLARE @total DECIMAL(10,2);
SELECT @total = SUM (precio*stock)
FROM productos
WHERE stock > 0;
RETURN @total;
END;

SELECT dbo.precio_total() AS GranTotal;


USE Proyecto_final
GO

CREATE PROCEDURE dbo.usp_RegistrarVentaSimple
    @cliente_id INT,
    @producto_id INT,
    @cantidad INT,
    @precio_unitario DECIMAL(10,2)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        -- Se declaran las variables locales
        DECLARE @venta_id INT;
        DECLARE @total DECIMAL(10,2) = @cantidad * @precio_unitario;

        INSERT INTO ventas (cliente_id, fecha_venta, total)
        VALUES (@cliente_id, GETDATE(), @total);

        SET @venta_id = SCOPE_IDENTITY();

        -- Se insertan los datos detallados de la venta
        INSERT INTO detalle_ventas (venta_id, producto_id, cantidad, precio_unitario)
        VALUES (@venta_id, @producto_id, @cantidad, @precio_unitario);

        --  Actualiza el stock disponible
        UPDATE productos
        SET stock = stock - @cantidad
        WHERE id = @producto_id; 

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO


--  Datos de prueba
EXEC dbo.usp_RegistrarVentaSimple 
    @cliente_id = 1, 
    @producto_id = 5, 
    @cantidad = 2, 
    @precio_unitario = 50.00;

-- Verificación
SELECT * FROM ventas;          
SELECT * FROM detalle_ventas;  
SELECT * FROM productos;       
