
--------------------------- Auditoria formal --------------------------------

USE master;
GO

CREATE SERVER AUDIT AuditoriaSeguridad
TO FILE ( FILEPATH = 'C:\Auditorias' ); 

-- Habilitamos la auditoría 
ALTER SERVER AUDIT AuditoriaSeguridad WITH (STATE = ON);
GO


CREATE SERVER AUDIT SPECIFICATION EspecificacionServidorAuditoria
FOR SERVER AUDIT AuditoriaSeguridad
    ADD (FAILED_LOGIN_GROUP),
    ADD (DATABASE_PERMISSION_CHANGE_GROUP),
    ADD (SERVER_OBJECT_PERMISSION_CHANGE_GROUP)
WITH (STATE = ON);
GO

USE Proyecto_final; -- Reemplaza con el nombre de tu base de datos
GO

CREATE DATABASE AUDIT SPECIFICATION EspecificacionVentasAuditoria
FOR SERVER AUDIT AuditoriaSeguridad
    ADD (DELETE ON OBJECT::dbo.ventas BY public) -- Audita DELETEs hechos por cualquier usuario (public)
WITH (STATE = ON);
GO

------------------------------------------------
----------- Eventos de prueba ------------------
------------------------------------------------

USE Proyecto_final
GO


-- Genero una venta para luego eliminarla 

EXEC dbo.usp_RegistrarVentaSimple 
    @cliente_id = 2, 
    @producto_id = 3, 
    @cantidad = 1, 
    @precio_unitario = 450.00; 

USE proyecto_final;
GO

DELETE FROM dbo.ventas 
WHERE id = 2;
GO

SELECT*FROM ventas;

-- Otorgo un permiso

GRANT SELECT ON dbo.ventas TO public;

----------------------------------------------
-------- Realizó la auditoría ----------------
----------------------------------------------

USE master;
GO

SELECT 
    event_time AS [Fecha y Hora (UTC)],
    action_id AS [Acción ID],
    succeeded AS [¿Exitoso?],
    session_server_principal_name AS [Usuario SQL],
    client_ip AS [IP Cliente], -- Identifica desde dónde lo hicieron
    database_name AS [Base de Datos],
    object_name AS [Objeto/Tabla],
    statement AS [Comando Ejecutado]
FROM 
    sys.fn_get_audit_file('C:\Auditorias\*', DEFAULT, DEFAULT)
ORDER BY 
    event_time DESC;
