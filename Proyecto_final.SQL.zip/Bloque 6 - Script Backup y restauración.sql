
------ Script para corroborar que el backup se haya realizado

SELECT 
    bs.database_name AS [Proyecto_final],
    CASE bs.type
        WHEN 'D' THEN 'Completo (Full)'
        WHEN 'I' THEN 'Diferencial'
        WHEN 'L' THEN 'Log de Transacciones'
    END AS [Tipo de Backup],
    bs.backup_start_date AS [Fecha de Inicio],
    bmf.physical_device_name AS [Ruta Física del Archivo],
    CAST(bs.backup_size / 1024.0 / 1024.0 AS DECIMAL(10, 2)) AS [Tamaño (MB)]
FROM msdb.dbo.backupset bs
INNER JOIN msdb.dbo.backupmediafamily bmf 
    ON bs.media_set_id = bmf.media_set_id
WHERE bs.database_name = 'Proyecto_final'
ORDER BY bs.backup_start_date DESC;

------- Script para verificar que la restauración se haya realizado

SELECT name, state_desc, user_access_desc 
FROM sys.databases 
WHERE name = 'Proyecto_final';

SELECT 
    destination_database_name AS [Base de Datos],
    restore_date AS [Fecha de Restauración],
    CASE restore_type 
        WHEN 'D' THEN 'Base de Datos Completa' 
        WHEN 'L' THEN 'Log de Transacciones' 
    END AS [Tipo de Restauración],
    user_name AS [Usuario que Restauró]
FROM msdb.dbo.restorehistory
WHERE destination_database_name = 'Proyecto_final'
ORDER BY restore_date DESC;

