
------------------------------ Seguridad y control ------------------------------------------

USE Proyecto_final;
GO     ----------------------------- creamos los logins para cada rol

-- Administrador
CREATE LOGIN [AdminUser] WITH PASSWORD = 'AdminPassword123!', CHECK_EXPIRATION = OFF, CHECK_POLICY = ON;
GO

-- Primer Cliente
CREATE LOGIN [ClienteUser1] WITH PASSWORD = 'ClientPassword123!', CHECK_EXPIRATION = OFF, CHECK_POLICY = ON;
GO

-- Segundo Cliente
CREATE LOGIN [ClienteUser2] WITH PASSWORD = 'ClientPassword456!', CHECK_EXPIRATION = OFF, CHECK_POLICY = ON;
GO

-- Vendedor
CREATE LOGIN [Vendedor] WITH PASSWORD = 'VendedorPassword123!', CHECK_EXPIRATION = OFF, CHECK_POLICY = ON;
GO

-- Auditor
CREATE LOGIN [Auditor] WITH PASSWORD = 'AudiPassword123!', CHECK_EXPIRATION = OFF, CHECK_POLICY = ON;
GO


-- Creamos los usuarios
USE [Proyecto_final];
GO

CREATE USER [AdminUser] FOR LOGIN [AdminUser];
CREATE USER [ClienteUser1] FOR LOGIN [ClienteUser1];
CREATE USER [ClienteUser2] FOR LOGIN [ClienteUser2];
CREATE USER [Vendedor] FOR LOGIN [Vendedor];
CREATE USER [Auditor] FOR LOGIN [Auditor];

GO

----- OTORGAMOS PERMISOS ---

GRANT CONTROL TO [AdminUser];
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON SCHEMA::dbo TO [ClienteUser1];
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON SCHEMA::dbo TO [ClienteUser2];
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON SCHEMA::dbo TO [Vendedor];
GO

GRANT EXECUTE ON dbo.usp_RegistrarVentaSimple TO [Auditor]
GO


------ Revocamos permisos para AdminUser para que solo obtenga permisos de lectura y actualización

REVOKE CONTROL ON DATABASE ::[Proyecto_final] TO [AdminUser];

ALTER ROLE db_datareader ADD MEMBER [AdminUser];

ALTER ROLE db_datawriter ADD MEMBER [AdminUser];

------- Principio de menor privilegio

-- Creamos un rol dedicado para la conexión de la página web

CREATE ROLE [Rol_Web_Ventas];
GO

-- Le damos permiso de ejecución EXCLUSIVAMENTE al procedimiento dbo.usp_RegistrarVentaSimple

GRANT EXECUTE ON dbo.usp_RegistrarVentaSimple TO [Rol_Web_Ventas];
GO

-- Modificamos los permisos para CienteUser 1 y ClienteUser2 para que no puedan modificar directamente las tablas

ALTER ROLE [Rol_Web_Ventas] ADD MEMBER [ClienteUser1];

ALTER ROLE [Rol_Web_Ventas] ADD MEMBER [ClienteUser2];
GO


-- Modificamos permisos para Auditor para solo lectura 

REVOKE EXECUTE ON dbo.usp_RegistrarVentaSimple TO [Auditor];
GO

ALTER ROLE db_datareader ADD MEMBER [Auditor];
GO
