
-------------------------------------------- automatización con triggers -----------------------------------------------

USE Proyecto_final
GO

------- UPDATE -----------

-- Trigger para registrar cambios de precio en UPDATE

CREATE TABLE Auditoria_Precios (
    id_auditoria INT IDENTITY(1,1) PRIMARY KEY, -- Se guardan los cambios en esta tabla
    id_producto INT NOT NULL,
    PrecioAnterior DECIMAL(10,2) NOT NULL,
    PrecioNuevo DECIMAL(10,2) NOT NULL,
    FechaCambio DATETIME NOT NULL,
    Usuario VARCHAR(100) NOT NULL
);
GO


CREATE TRIGGER TR_Productos_Update_Precio
ON Productos
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Verifica si la columna Precio fue modificada
    IF UPDATE(precio)
    BEGIN
        -- Inserta el historial solo si el precio realmente cambió
        INSERT INTO Auditoria_Precios (id_producto, PrecioAnterior, PrecioNuevo, FechaCambio, Usuario)
        SELECT 
            d.id, 
            d.precio, 
            i.precio, 
            GETDATE(), 
            SYSTEM_USER
        FROM inserted i
        JOIN deleted d ON i.id = d.id
        WHERE i.precio <> d.precio;
    END;
END;
GO

SELECT id, nombre, precio 
FROM productos 
WHERE nombre LIKE '%heladera%';

UPDATE productos 
SET precio = 450.00 
WHERE id = 3; 

SELECT*FROM productos;
SELECT*FROM Auditoria_precios;

------- INSERT ------------

-- Trigger para registrar auditoría en INSERT en ventas

CREATE TABLE Auditoria_Ventas (
    id_auditoria INT IDENTITY(1,1) PRIMARY KEY,
    venta_id INT NOT NULL,
    cliente_id INT NOT NULL,
    total_venta DECIMAL(10,2) NOT NULL,
    fecha_auditoria DATETIME NOT NULL,
    usuario VARCHAR(100) NOT NULL
);
GO


CREATE TRIGGER TR_Ventas_Insert_Auditoria
ON ventas
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    -- Inserta en la auditoría cada vez que se registra una nueva venta
    INSERT INTO Auditoria_Ventas (venta_id, cliente_id, total_venta, fecha_auditoria, usuario)
    SELECT 
        i.id, 
        i.cliente_id, 
        i.total, 
        GETDATE(), 
        SYSTEM_USER
    FROM inserted i;
END;
GO


INSERT INTO ventas(cliente_id,fecha_venta) VALUES ('2','2026-10-05 11:15:00');
SELECT*FROM Auditoria_Ventas;
SELECT*FROM ventas;

-------------- Trigger en vista compleja ------------

CREATE TRIGGER TR_Vista_Productos_InsteadOfInsert
ON Vista_Productos_Categorias
INSTEAD OF INSERT
AS
BEGIN
    SET NOCOUNT ON;

    -- Declaramos variables para procesar fila por fila (o la primera fila)
    DECLARE @prod_nombre VARCHAR(50), @precio DECIMAL(10,2), @stock INT, @cat_nombre VARCHAR(50);
    DECLARE @cat_id INT;

    -- Obtenemos los datos que el usuario intentó insertar
    SELECT 
        @prod_nombre = producto_nombre,
        @precio = precio,
        @stock = stock,
        @cat_nombre = categoria_nombre
    FROM inserted;

    --  Verificar si la categoría ya existe
    SELECT @cat_id = id FROM categorías WHERE nombre = @cat_nombre;

    -- Si no existe, la creamos en su respectiva tabla
    IF @cat_id IS NULL
    BEGIN
        INSERT INTO categorías (nombre) VALUES (@cat_nombre);
        SET @cat_id = SCOPE_IDENTITY(); -- Capturamos el ID recién generado
    END

    -- Insertar el producto final con el ID de categoría correcto
    INSERT INTO productos (nombre, precio, stock, categoria_id)
    VALUES (@prod_nombre, @precio, @stock, @cat_id);
END;
GO


INSERT INTO Vista_Productos_Categorias (producto_nombre, precio, stock, categoria_nombre)
VALUES ('Microondas', 250.00, 10, 'Electrodomésticos');

SELECT*FROM Vista_Productos_Categorias;

