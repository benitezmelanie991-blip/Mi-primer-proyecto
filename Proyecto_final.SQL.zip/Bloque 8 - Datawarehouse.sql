
-------------------------------- DATA WAREHOUSE -----------------------------------

IF OBJECT_ID('dbo.FactVentas','U') IS NOT NULL DROP TABLE dbo.FactVentas;
IF OBJECT_ID('dbo.DimTiempo','U') IS NOT NULL DROP TABLE dbo.DimTiempo;
IF OBJECT_ID('dbo.DimCliente','U') IS NOT NULL DROP TABLE dbo.DimCliente;
IF OBJECT_ID('dbo.DimProducto','U') IS NOT NULL DROP TABLE dbo.DimProducto;
GO

-- Crear tablas de dimensiones

CREATE TABLE dbo.DimProducto (
    ProductoSK INT IDENTITY(1,1) PRIMARY KEY,
    ProductoID INT NOT NULL UNIQUE,
    Nombre NVARCHAR(100) NOT NULL,
    Categoria NVARCHAR(100) NOT NULL
);

CREATE TABLE dbo.DimCliente (
    ClienteSK INT IDENTITY(1,1) PRIMARY KEY,
    ClienteID INT NOT NULL UNIQUE,
    Nombre NVARCHAR(100) NOT NULL,
    Ciudad NVARCHAR(100) NOT NULL
);

CREATE TABLE dbo.DimTiempo (
    TiempoSK INT IDENTITY(1,1) PRIMARY KEY,
    Fecha DATE NOT NULL UNIQUE,
    Anio INT NOT NULL,
    Mes INT NOT NULL,
    Dia INT NOT NULL
);

CREATE TABLE dbo.HechoVentas (
    ProductoSK INT NOT NULL,
    ClienteSK INT NOT NULL,
    TiempoSK INT NOT NULL,
    FacturaNumero INT NOT NULL,
    Cantidad INT NOT NULL,
    PrecioUnitario DECIMAL(18,2) NOT NULL,
    MontoTotal DECIMAL(18,2) NOT NULL,
    CONSTRAINT PK_HechoVentas PRIMARY KEY (ProductoSK, ClienteSK, TiempoSK, FacturaNumero),
    CONSTRAINT FK_HechoVentas_DimProducto FOREIGN KEY (ProductoSK) REFERENCES dbo.DimProducto(ProductoSK),
    CONSTRAINT FK_HechoVentas_DimCliente FOREIGN KEY (ClienteSK) REFERENCES dbo.DimCliente(ClienteSK),
    CONSTRAINT FK_HechoVentas_DimTiempo FOREIGN KEY (TiempoSK) REFERENCES dbo.DimTiempo(TiempoSK)
);


-- ==========================================
-- ETL: POBLAMOS DIMENSION CLIENTE 
-- ==========================================
INSERT INTO dbo.DimCliente (ClienteID, Nombre, Ciudad)
SELECT 
    c.id AS ClienteID,          
    c.nombre, 
    'No Informado' AS Ciudad    
FROM Proyecto_final.dbo.clientes c
WHERE NOT EXISTS (
    SELECT 1 FROM dbo.DimCliente dc WHERE dc.ClienteID = c.id
);

-- ==========================================
-- ETL: POBLAMOS DIMENSION PRODUCTO 
-- ==========================================
INSERT INTO dbo.DimProducto (ProductoID, Nombre, Categoria)
SELECT 
    p.id AS ProductoID,        
    p.nombre, 
    cat.nombre AS Categoria     
FROM Proyecto_final.dbo.productos p
INNER JOIN Proyecto_final.dbo.categorías cat ON p.categoria_id = cat.id 
WHERE NOT EXISTS (
    SELECT 1 FROM dbo.DimProducto dp WHERE dp.ProductoID = p.id
);

-- ==========================================
-- ETL: POBLAMOS DIMENSION TIEMPO 
-- ==========================================
DECLARE @FechaInicio DATE = '2026-01-01';
DECLARE @FechaFin DATE = '2026-12-31';

WHILE @FechaInicio <= @FechaFin
BEGIN
    IF NOT EXISTS (SELECT 1 FROM dbo.DimTiempo WHERE Fecha = @FechaInicio)
    BEGIN
        INSERT INTO dbo.DimTiempo (Fecha, Anio, Mes, Dia)
        VALUES (
            @FechaInicio,
            YEAR(@FechaInicio),
            MONTH(@FechaInicio),
            DAY(@FechaInicio)
        );
    END
    SET @FechaInicio = DATEADD(day, 1, @FechaInicio);
END;

-- ==========================================
-- ETL: POBLAMOS TABLA HECHO VENTAS 
-- ==========================================
INSERT INTO dbo.HechoVentas (
    ProductoSK, 
    ClienteSK, 
    TiempoSK, 
    FacturaNumero, 
    Cantidad, 
    PrecioUnitario, 
    MontoTotal
)
SELECT 
    dp.ProductoSK,
    dc.ClienteSK,
    dt.TiempoSK,
    v.id AS FacturaNumero,            
    dv.cantidad AS Cantidad,
    dv.precio_unitario AS PrecioUnitario,
    dv.subtotal AS MontoTotal          
FROM Proyecto_final.dbo.detalle_ventas dv
INNER JOIN Proyecto_final.dbo.ventas v ON dv.venta_id = v.id
INNER JOIN dbo.DimProducto dp ON dv.producto_id = dp.ProductoID 
INNER JOIN dbo.DimCliente dc ON v.cliente_id = dc.ClienteID   
INNER JOIN dbo.DimTiempo dt ON CAST(v.fecha_venta AS DATE) = dt.Fecha
WHERE NOT EXISTS (
    SELECT 1 FROM dbo.HechoVentas hv
    WHERE hv.ProductoSK = dp.ProductoSK
      AND hv.ClienteSK = dc.ClienteSK
      AND hv.TiempoSK = dt.TiempoSK
      AND hv.FacturaNumero = v.id
);

SELECT*FROM dbo.HechoVentas;
SELECT*FROM dbo.DimCliente;
SELECT*FROM dbo.HechoVentas;


------------- Consultas analíticas


SELECT 
    dt.Anio,
    dt.Mes,
    COUNT(DISTINCT hv.FacturaNumero) AS TotalTransacciones,
    SUM(hv.Cantidad) AS UnidadesVendidas,
    SUM(hv.MontoTotal) AS IngresosTotales
FROM dbo.HechoVentas hv
INNER JOIN dbo.DimTiempo dt ON hv.TiempoSK = dt.TiempoSK
GROUP BY dt.Anio, dt.Mes
ORDER BY dt.Anio DESC, dt.Mes ASC;

SELECT TOP 5
    dc.ClienteID,
    dc.Nombre AS NombreCliente,
    dc.Ciudad,
    SUM(hv.MontoTotal) AS TotalGastado,
    COUNT(DISTINCT hv.FacturaNumero) AS VisitasAlNegocio
FROM dbo.HechoVentas hv
INNER JOIN dbo.DimCliente dc ON hv.ClienteSK = dc.ClienteSK
GROUP BY dc.ClienteID, dc.Nombre, dc.Ciudad
ORDER BY TotalGastado DESC;


SELECT 
    dp.Categoria,
    dp.Nombre AS NombreProducto,
    SUM(hv.Cantidad) AS TotalUnidadesVendidas,
    SUM(hv.MontoTotal) AS TotalRecaudado
FROM dbo.HechoVentas hv
INNER JOIN dbo.DimProducto dp ON hv.ProductoSK = dp.ProductoSK
GROUP BY dp.Categoria, dp.Nombre
ORDER BY dp.Categoria ASC, TotalRecaudado DESC;

SELECT 
    dt.Anio,
    SUM(hv.MontoTotal) AS IngresosTotales,
    COUNT(DISTINCT hv.FacturaNumero) AS TotalFacturas,
    -- Calculamos el promedio dividiendo el ingreso total entre el número de facturas
    ROUND(SUM(hv.MontoTotal) / COUNT(DISTINCT hv.FacturaNumero), 2) AS TicketPromedio
FROM dbo.HechoVentas hv
INNER JOIN dbo.DimTiempo dt ON hv.TiempoSK = dt.TiempoSK
GROUP BY dt.Anio
ORDER BY dt.Anio DESC;

-------------- Comparación OLTP con OLAP

-- Consulta en el OLTP (Más compleja y lenta) --

SELECT 
    cat.nombre AS Categoria,
    SUM(dv.cantidad * dv.precio_unitario) AS TotalVendido
FROM Proyecto_final.dbo.detalle_ventas dv
INNER JOIN Proyecto_final.dbo.ventas v ON dv.venta_id = v.id
INNER JOIN Proyecto_final.dbo.productos p ON dv.producto_id = p.id
INNER JOIN Proyecto_final.dbo.categorías cat ON p.categoria_id = cat.id
WHERE YEAR(v.fecha_venta) = 2026
GROUP BY cat.nombre;

-- Consulta en el OLAP (Simple y veloz) --

SELECT 
    dp.Categoria,
    SUM(hv.MontoTotal) AS TotalVendido
FROM dbo.HechoVentas hv
INNER JOIN dbo.DimProducto dp ON hv.ProductoSK = dp.ProductoSK
INNER JOIN dbo.DimTiempo dt ON hv.TiempoSK = dt.TiempoSK
WHERE dt.Anio = 2026
GROUP BY dp.Categoria;
