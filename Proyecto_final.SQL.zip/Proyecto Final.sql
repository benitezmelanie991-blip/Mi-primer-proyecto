
DROP DATABASE IF EXISTS Proyecto_final;
CREATE DATABASE Proyecto_final;
USE Proyecto_final;
GO
--------------------------------------------------- TABLAS ---------------------------------------------------------------------

CREATE TABLE categorías(
id INT IDENTITY(1,1)PRIMARY KEY,
nombre VARCHAR(100)UNIQUE NOT NULL,
descripcion VARCHAR(100),
);

CREATE TABLE clientes(
id INT PRIMARY KEY,
nombre VARCHAR(50),
email VARCHAR(50) UNIQUE NOT NULL,
telefono  VARCHAR(20),
username VARCHAR(50) UNIQUE NOT NULL,
password_hash VARCHAR(50) NOT NULL,
rol VARCHAR(20) DEFAULT 'cliente'CHECK(rol IN('cliente', 'administrador', 'empleado')),
activo BIT DEFAULT 1,
fecha_registro DATETIME DEFAULT GETDATE()
);

CREATE TABLE productos(
id INT IDENTITY(1,1) PRIMARY KEY,
nombre VARCHAR(50)NOT NULL,
precio DECIMAL(10,2) NOT NULL CHECK(precio >= 0),
stock INT NOT NULL CHECK(stock >= 0),
categoria_id INT,
CONSTRAINT fk_categoria_id_productos FOREIGN KEY (categoria_id) REFERENCES categorías(id) ON UPDATE CASCADE
);

CREATE TABLE ventas(
id INT IDENTITY(1,1) PRIMARY KEY,
cliente_id INT NOT NULL,
fecha_venta DATETIME DEFAULT GETDATE(),
total DECIMAL(10,2)NOT NULL DEFAULT 0,
CONSTRAINT fk_cliente_id_ventas FOREIGN KEY(cliente_id) REFERENCES clientes(id) ON DELETE CASCADE
);

CREATE TABLE detalle_ventas(
id INT IDENTITY(1,1) PRIMARY KEY,
venta_id INT NOT NULL,
producto_id INT NOT NULL,
cantidad INT NOT NULL CHECK (cantidad > 0),
precio_unitario DECIMAL(10,2) NOT NULL,
subtotal AS (cantidad*precio_unitario),
CONSTRAINT fk_venta_id_detalle_ventas FOREIGN KEY (venta_id) REFERENCES ventas(id) ON DELETE CASCADE,
CONSTRAINT fk_producto_id_detalle_ventas FOREIGN KEY (producto_id) REFERENCES productos(id)
);

--------------------------------------------- DATOS DE PRUEBA ----------------------------------------------------------------------

-- inserción de datos a la tabla Clientes --

INSERT INTO clientes (id,nombre,email,telefono,username,password_hash,rol,fecha_registro) VALUES (
'1','Juan Perez','Juan.Perez@gmail.com','1135002312','Jperez','$2b$12$e09aZxyz','Cliente','2024-06-20 12:12:00'),
('2','Ana Gomez','Pepita.Gomez@gmail.com','1142001212','Ana.Gomez','$2b$12$K19mPqrs','Cliente','2026-05-12 13:45:00'),
('3','Carlos Ruiz','Carlos1234@gmai.com','1139240013','Carlos_Ruiz','$3t$34$m25mWWIO','Cliente','2025-02-05 09:10:23'),
('4','Lucia Torres','TorresLucia123@gmail.com','1141009087','LuTorres','%34$g4$t%5rt$Abd','Cliente','2025-12-20 00:15:34'),
('5','Maria Gutierrez','Mgutierrez13@gmail.com','112344556','GMaria_1','$b2%34t$St5$','Empleado','2026-03-23 20:30:12'),
('6','Lucas Benitez','BenitezLucas1019@gmail.com','1109876543','Lucas_Be_2','$2b$12$X93vBtWn','Administrador','2026-04-21 23:25:00');

-- inserción de datos a la tabla Productos --

INSERT INTO productos (nombre,precio,stock,categoria_id) VALUES
('Espejo','20.00','50','1'),
('Lampara','16.50','25','1'),
('Heladera','499.99','5','2'),
('Cafetera','230.50','12','2'),
('Respaldo','80.00','20','3'),
('Acolchado','59.50','40','3'),
('Platos','23.00','50','4'),
('Cuchillos','12.50','120','4');

-- inserción de datos a la tabla categorías --

INSERT INTO categorías (nombre,descripcion) VALUES (
'Hogar','decoracion y accesorios para todos tus ambientes'),
('Electrodomesticos','Aparatos electronicos modernos para facilitar tareas diarias'),
('dormitorio','Colchones, sabanas, almohadas y mobiliario para decorar tu cuarto'),
('cocina','utensilios,vajilla y pequeños artefactos para preparar y servir tus comidas');

------------------------------------------------------ Vistas -------------------------------------------------------------

USE Proyecto_final;
GO

CREATE VIEW dbo.VistaProductosHogar -- visualización de productos dentro de la categoría hogar --
AS
SELECT 
    p.id AS ProductoID,
    p.nombre AS NombreProducto,
    p.precio,
    p.stock,
    c.nombre AS NombreCategoria
FROM productos p
INNER JOIN categorías c ON p.categoria_id = c.id
WHERE c.nombre = 'Hogar';
GO

SELECT*FROM dbo.VistaProductosHogar;



CREATE VIEW Vista_Productos_Categorias AS ---- une la tabla de productos con su categoría para mostrar el nombre de la categoría en lugar de solo su ID
SELECT 
    p.id AS producto_id,
    p.nombre AS producto_nombre,
    p.precio,
    p.stock,
    c.id AS categoria_id,
    c.nombre AS categoria_nombre
FROM productos p
JOIN categorías c ON p.categoria_id = c.id;
GO

 SELECT*FROM Vista_Productos_Categorias;
